// Kiểm tra đăng nhập
document.addEventListener('DOMContentLoaded', () => {
  const username = localStorage.getItem('loggedInUser');
  if (!username) {
    alert('Vui lòng đăng nhập trước');
    window.location.href = 'login.html';
    return;
  }

  // Hiển thị tên người dùng
  const userLabel = document.getElementById('user-label');
  if (userLabel) {
    userLabel.textContent = username;
  }

  // Xử lý dropdown đăng xuất
  const userDiv = document.getElementById('user-name');
  const dropdown = document.getElementById('user-dropdown');

  if (userDiv && dropdown) {
    userDiv.addEventListener('click', () => {
      dropdown.style.display = dropdown.style.display === 'block' ? 'none' : 'block';
    });

    // Ẩn dropdown khi click ra ngoài
    document.addEventListener('click', (e) => {
      if (!userDiv.contains(e.target)) {
        dropdown.style.display = 'none';
      }
    });
  }
});

// Hàm đăng xuất
function logout() {
  localStorage.removeItem('loggedInUser');
  localStorage.removeItem('loggedInRole');
  window.location.href = 'login.html';
}
