function register() {
  const username = document.getElementById('register-username').value;
  const password = document.getElementById('register-password').value;
  if (username && password) {
    localStorage.setItem('user_' + username, password);
    alert('Đăng ký thành công');
    window.location.href = 'login.html';
  } else {
    alert('Vui lòng nhập đầy đủ thông tin');
  }
}
function login() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  const storedPassword = localStorage.getItem('user_' + username);
  if (storedPassword === password) {
    localStorage.setItem('loggedInUser', username);
    window.location.href = 'index.html';
  } else {
    alert('Sai tên đăng nhập hoặc mật khẩu');
  }
}
function checkLogin() {
  const user = localStorage.getItem('loggedInUser');
  if (!user) {
    alert('Vui lòng đăng nhập trước');
    window.location.href = 'login.html';
  } else {
    document.getElementById('userDisplay').innerText = user;
    showScores();
  }
}
function logout() {
  localStorage.removeItem('loggedInUser');
  window.location.href = 'login.html';
}
function showSection(sectionId) {
  document.querySelectorAll('.section').forEach(div => div.style.display = 'none');
  document.getElementById(sectionId).style.display = 'block';
}
function addStudent() {
  const id = document.getElementById('studentId').value;
  const name = document.getElementById('studentName').value;
  const cls = document.getElementById('studentClass').value;
  const students = JSON.parse(localStorage.getItem('students') || '[]');
  students.push({ id, name, cls });
  localStorage.setItem('students', JSON.stringify(students));
  alert('Thêm sinh viên thành công');
}
function addMark() {
  const id = document.getElementById('markStudentId').value;
  const subject = document.getElementById('subject').value;
  const mark = parseFloat(document.getElementById('mark').value);
  const marks = JSON.parse(localStorage.getItem('marks') || '[]');
  marks.push({ id, subject, mark });
  localStorage.setItem('marks', JSON.stringify(marks));
  alert('Thêm điểm thành công');
  showScores();
}
function showScores() {
  const marks = JSON.parse(localStorage.getItem('marks') || '[]');
  const div = document.getElementById('scoreList');
  div.innerHTML = '<table border="1"><tr><th>Mã SV</th><th>Môn</th><th>Điểm</th></tr>' +
    marks.map(m => `<tr><td>${m.id}</td><td>${m.subject}</td><td>${m.mark}</td></tr>`).join('') +
    '</table>';
}