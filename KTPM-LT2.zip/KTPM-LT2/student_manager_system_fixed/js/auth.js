function register() {
  const username = document.getElementById('register-username').value;
  const password = document.getElementById('register-password').value;
  const role = document.getElementById('register-role').value;

  if (username && password && role) {
    localStorage.setItem('user_' + username, password);
    localStorage.setItem('role_' + username, role);
    alert('Đăng ký thành công');
    window.location.href = 'login.html';
  } else {
    alert('Vui lòng nhập đầy đủ thông tin');
  }
}

function login() {
  const username = document.getElementById('login-username').value;
  const password = document.getElementById('login-password').value;
  const role = document.getElementById('login-role').value;

  const storedPassword = localStorage.getItem('user_' + username);
  const storedRole = localStorage.getItem('role_' + username);

  if (storedPassword === password && storedRole === role) {
    localStorage.setItem('loggedInUser', username);
    localStorage.setItem('loggedInRole', role);
    window.location.href = 'index.html';
  } else {
    alert('Sai tên đăng nhập, mật khẩu hoặc vai trò');
  }
}

function logout() {
  localStorage.removeItem('loggedInUser');
  localStorage.removeItem('loggedInRole');
  window.location.href = 'login.html';
}
